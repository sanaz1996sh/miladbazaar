from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(shopcls)
admin.site.register(contactcls)
admin.site.register(blogcls)
admin.site.register(officecls)
admin.site.register(servicescls)
admin.site.register(aboutcls)
admin.site.register(homeimgcls)
